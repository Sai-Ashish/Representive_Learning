#this is for 3 hidden nodes per mean and sigma respectively
import numpy as np
import matplotlib.pyplot as plt
import os
np.random.seed(42)

def load_flattened_images(Loc):
    Images = []
    for root, dirs, files in os.walk(Loc):
        for file in files:
            Image = plt.imread(os.path.join(root, file))
            Image = Image / 255.0
            Images.append(Image.flatten())
                
    Images = np.asarray(Images)
    print(Images.shape)

    return Images

for i in range(0,10):
	X=load_flattened_images('trainingData/'+str(i))
	print X.shape
	X=np.reshape(X, (X.shape[0], 28, 28))
	print X.shape
	np.save(str(i)+".npy",X)